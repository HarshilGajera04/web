﻿<?php include 'header.php'; ?>

<!-- start banner -->
<section class="p-0 top-space-margin position-relative overflow-hidden">
    <div class="container-fluid p-0 h-100 position-relative">
        <div class="row g-0">
            <div class="col-xl-4 col-lg-5 d-flex justify-content-center align-items-center ps-10 xxl-ps-6 xl-ps-4 md-ps-4 sm-ps-0 position-relative order-2 order-lg-1"
                data-anime='{ "el": "childs", "translateY": [30, 0], "opacity": [0,1], "duration": 600, "delay":0, "staggervalue": 300, "easing": "easeOutQuad" }'>
                <div
                    class="vertical-title-center align-items-center justify-content-center flex-shrink-0 w-75px sm-w-50px">
                    <h1 class="title fs-15 alt-font text-dark-gray fw-700 text-uppercase ls-1px text-uppercase d-flex w-auto align-items-center m-0"
                        data-fancy-text='{ "opacity": [0, 1], "translateY": [50, 0], "filter": ["blur(20px)", "blur(0px)"], "string": ["contact us"], "duration": 400, "delay": 0, "speed": 50, "easing": "easeOutQuad" }'>
                    </h1>
                </div>
                <div class="border-start border-color-extra-medium-gray ps-40px sm-ps-20px position-relative z-index-9">
                    <h2
                        class="text-dark-gray fw-600 alt-font outside-box-right-10 xl-outside-box-right-15 lg-outside-box-right-20 md-me-0 sm-mb-0 ls-minus-3px">
                        We're here to here answer & question you may have.</h2>
                </div>
            </div>
            <div class="col-xl-8 col-lg-7 position-relative one-half-screen order-1 order-lg-2 md-mb-50px">
                <div class="overflow-hidden position-relative">
                    <div class="w-100"
                        data-anime='{ "effect": "slide", "direction": "lr", "color": "#f7f7f7", "duration": 1000, "delay": 0 }'>
                        <img src="https://via.placeholder.com/1149x800" alt="" class="w-100 liquid-parallax"
                            data-parallax-liquid="true" data-parallax-position="top" data-parallax-scale="1.05">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- end banner -->
<!-- start section -->
<section>
    <div class="container">
        <div class="row"
            data-anime='{ "el": "childs", "translateX": [30, 0], "opacity": [0,1], "duration": 600, "delay":0, "staggervalue": 300, "easing": "easeOutQuad" }'>
            <div class="col-md-4 sm-mb-30px">
                <span class="fs-30 alt-font ls-minus-05px fw-700 text-dark-gray">London</span>
                <p class="w-70 mb-10px lg-w-90">301 Sondanella, Eden walk, Orchard view, London, UK</p>
                <div class="separator-line-1px bg-extra-medium-gray w-70 mt-20px mb-20px md-w-100"></div>
                <div class="d-block">
                    <span class="text-dark-gray fw-600">E:</span>
                    <a href="mailto:info@yourdomain.com">info@yourdomain.com</a>
                </div>
                <div class="d-block mb-5px">
                    <span class="text-dark-gray fw-600">T:</span>
                    <a href="tel:12345678910">123 456 7890</a>
                </div>
                <a href="https://maps.google.com/maps?ll=-37.805688,144.962312&amp;z=17&amp;t=m&amp;hl=en-US&amp;gl=IN&amp;mapclient=embed&amp;cid=13153204942596594449"
                    target="_blank" class="fs-14 text-dark-gray text-uppercase fw-600">
                    <span class=""><i class="feather icon-feather-map-pin fs-14 me-5px"></i>View on google map</span>
                </a>
            </div>
            <div class="col-md-4 sm-mb-30px">
                <span class="fs-30 alt-font ls-minus-05px fw-700 text-dark-gray">New York</span>
                <p class="w-70 mb-10px lg-w-90 md-w-100">27 Eden walk eden centre, Orchard view, New York, USA</p>
                <div class="separator-line-1px bg-extra-medium-gray w-70 mt-20px mb-20px md-w-100"></div>
                <div class="d-block">
                    <span class="text-dark-gray fw-600">E:</span>
                    <a href="mailto:info@yourdomain.com">info@yourdomain.com</a>
                </div>
                <div class="d-block mb-5px">
                    <span class="text-dark-gray fw-600">T:</span>
                    <a href="tel:12345678910">123 456 7890</a>
                </div>
                <a href="https://maps.google.com/maps?ll=-37.805688,144.962312&amp;z=17&amp;t=m&amp;hl=en-US&amp;gl=IN&amp;mapclient=embed&amp;cid=13153204942596594449"
                    target="_blank" class="fs-14 text-dark-gray text-uppercase fw-600">
                    <span class=""><i class="feather icon-feather-map-pin fs-14 me-5px"></i>View on google map</span>
                </a>
            </div>
            <div class="col-md-4">
                <span class="fs-30 alt-font ls-minus-05px fw-700 text-dark-gray">Dubai</span>
                <p class="w-70 mb-10px lg-w-80 md-w-100">701 Sondanella, 24th Floor, Valley road, Dubai, Emirates</p>
                <div class="separator-line-1px bg-extra-medium-gray w-70 mt-20px mb-20px md-w-100"></div>
                <div class="d-block">
                    <span class="text-dark-gray fw-600">E:</span>
                    <a href="mailto:info@yourdomain.com">info@yourdomain.com</a>
                </div>
                <div class="d-block mb-5px">
                    <span class="text-dark-gray fw-600">T:</span>
                    <a href="tel:12345678910">123 456 7890</a>
                </div>
                <a href="https://maps.google.com/maps?ll=-37.805688,144.962312&amp;z=17&amp;t=m&amp;hl=en-US&amp;gl=IN&amp;mapclient=embed&amp;cid=13153204942596594449"
                    target="_blank" class="fs-14 text-dark-gray text-uppercase fw-600">
                    <span class=""><i class="feather icon-feather-map-pin fs-14 me-5px"></i>View on google map</span>
                </a>
            </div>
        </div>
    </div>
</section>
<!-- end section -->

<!-- start section -->
<section class="p-0">
    <div class="container-fluid p-0">
        <div class="row g-0">
            <div class="map col-md-12">
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d118147.68689143502!2d70.73889534133134!3d22.273625026645934!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3959c98ac71cdf0f%3A0x76dd15cfbe93ad3b!2sRajkot%2C%20Gujarat!5e0!3m2!1sen!2sin!4v1711101837503!5m2!1sen!2sin"
                    width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                    referrerpolicy="no-referrer-when-downgrade"></iframe>
                <!-- <div id="map" class="map h-650px md-h-500px sm-h-400px"
                    data-map-options='{ "lat": -37.805688, "lng": 144.962312, "style": "Silver", "marker": { "type": "HTML", "color": "#232323" }, "popup": { "defaultOpen": true, "html": "<div class=infowindow><strong class=\"mb-3 d-inline-block alt-font\">Crafto Branding</strong><p class=\"alt-font\">16122 Collins street, Melbourne, Australia</p></div><div class=\"google-maps-link alt-font\"> <a aria-label=\"View larger map\" target=\"_blank\" jstcache=\"31\" href=\"https://maps.google.com/maps?ll=-37.805688,144.962312&amp;z=17&amp;t=m&amp;hl=en-US&amp;gl=IN&amp;mapclient=embed&amp;cid=13153204942596594449\" jsaction=\"mouseup:placeCard.largerMap\">VIEW LARGER MAP</a></div>" } }'> -->
            </div>
        </div>
    </div>
    </div>
</section>
<!-- end section -->

<!-- start section -->
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-12 col-md-12 col-sm-12 text-center elements-social social-icon-style-06">
                <div class="fs-22 mb-30px text-dark-gray">Connect with <span class="fw-600">social media</span></div>
                <ul class="extra-large-icon fw-600"
                    data-anime='{ "el": "childs", "translateX": [10, 0], "opacity": [0,1], "duration": 300, "delay": 100, "staggervalue": 300, "easing": "easeOutQuad" }'>
                    <li><a class="facebook" href="https://www.facebook.com" target="_blank"><span
                                class="brand-label text-dark-gray">Fb</span><span
                                class="brand-icon fa-brands fa-facebook-f"></span></a></li>
                    <li><a class="instagram" href="https://in.instagram.com" target="_blank"><span
                                class="brand-label text-dark-gray">Ig</span><span
                                class="brand-icon fa-brands fa-instagram"></span></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<!-- end section -->

<?php include 'footer.php'; ?>